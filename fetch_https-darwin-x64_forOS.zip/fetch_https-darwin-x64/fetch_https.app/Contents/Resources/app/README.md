# Fetch_https

    将fetch_https-darwin-x64下载到本地。

#   一、Https如何抓取？

       1、打开App

       2、手机设置代理

       设置手机代理到本地IP,8899端口。

       3、iOS手机打开Safari浏览器，访问http://rootca.pro/

       按提示点击安装证书。

       4、回到App菜单栏，点击Https按钮,勾选“Intercept HTTPS CONNECTs”选项。

       5、打开带https请求的页面，尝试是否能够抓包。
